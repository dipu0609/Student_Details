package com.restapi.crud.crud.model;

public class crudmodel {
	private int id;
	private String name;
	private int DOB;
     private int DOJ;


	public crudmodel() {

	}

	public crudmodel(int id, String name, int DOB,int DOJ) {
		super();
		this.id = id;
		this.name = name;
		this.DOB=DOB;
        this.DOJ=DOJ;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getDOB() {
		return DOB;
	}

	public void setDOB(int DOB) {
		this.DOB = DOB;
	}
	public int getDOJ() {
		return DOJ;
	}

	public void setDOJ(int DOJ) {
		this.DOJ = DOJ;
	}
	

	
	
	
	
	
	

}
